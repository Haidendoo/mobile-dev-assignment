# Forest Sokoban — Section 6

Gói này cung cấp phần **6. Data and API Design** để thay phần 6 đang để trống trong báo cáo A01. Nội dung viết bằng tiếng Anh, dựa trên đặc tả v1.1-r1 và hợp đồng API của dự án.

## Các file

- `Forest_Sokoban_A01_Section_6.tex`: nội dung để chèn vào báo cáo chính.
- `Forest_Sokoban_A01_Section_6_Preview.tex`: file chính để biên dịch riêng và xem thử.
- `Forest_Sokoban_A01_Section_6_Preview.pdf`: PDF xem trước.
- `docs/api/openapi.json`: hợp đồng API có kiểu dữ liệu và schema đầy đủ.

Sơ đồ dữ liệu được vẽ bằng TikZ ngay trong `.tex`. Không cần tải thêm ảnh, logo hay file `.bib` cho phần 6.

## Chèn vào báo cáo hiện có

1. Upload các file trong ZIP lên project Overleaf hiện có. Đặt file `Forest_Sokoban_A01_Section_6.tex` cùng thư mục với file `.tex` chính.
2. Trong file chính, xóa toàn bộ phần 6 cũ, từ dòng `\section{Data and API Design}` đến ngay trước dòng `\def\ForestSokobanIncludeMode{1}`. Phần bị xóa gồm cả hình ERD placeholder, bảng API placeholder và các hướng dẫn chưa điền.
3. Thay khối vừa xóa bằng đúng dòng này:

```tex
\input{Forest_Sokoban_A01_Section_6.tex}
```

Giữ phần `\input` của Sections 7–9 ở phía sau. File nội dung không đặt lại bộ đếm; khi chèn sau Section 5, LaTeX tự đánh số thành Section 6. Không thêm `\documentclass`, `\begin{document}` hay `\end{document}` quanh dòng chèn này.

Template đã có các package cần dùng: `array`, `booktabs`, `longtable`, `tabularx`, `ragged2e`, `graphicx`, `tikz`, `listings`, `xcolor`, `hyperref`, `url`.

## Tích hợp vào báo cáo

Section 6 hiện chứa trực tiếp mô hình dữ liệu, hợp đồng API, ví dụ request/response và bảng lỗi. Không chèn lại nội dung Data/API ở phần tiếp nối. Các nhãn của bảng Section 6 dùng nhãn tại chỗ, chẳng hạn `tab:api`.

File Section 6 không tạo bibliography riêng; không thêm một khối bibliography thứ hai từ gói này. Nếu file Sections 7–9 đã có `thebibliography`, kiểm tra để báo cáo chỉ dùng một cách quản lý tài liệu tham khảo thống nhất.

## Xem riêng trên Overleaf

Nếu muốn xem riêng trước khi chèn, upload ZIP vào một project mới và chọn `Forest_Sokoban_A01_Section_6_Preview.tex` làm Main document, dùng pdfLaTeX. File preview đặt bộ đếm ở 5 để bắt đầu đúng số 6. Khi ghép báo cáo, dùng file nội dung, không dùng file preview.

## Phạm vi kiểm tra

- Đã biên dịch PDF xem trước 12 trang, kiểm tra số mục và tham chiếu; log không có lỗi tràn dòng Overfull.
- Các ví dụ JSON đều parse được; các ví dụ API được đối chiếu với schema trong `openapi.json`.
- Thiết kế giữ campaign/challenge tách biệt, ownership theo tài khoản, score casual chưa xác minh và challenge xác minh trên server.
- Các endpoint và chính sách trong báo cáo là thiết kế đề xuất. Việc kiểm tra schema hoặc biên dịch tài liệu không chứng minh backend đã được triển khai hay vượt qua kiểm thử A02.