# Bản LaTeX đã bổ sung UI

File nội dung: `Forest_Sokoban_A01_Sections_7_to_End.tex`.

Ảnh đang dùng: `figures/ui/compact/`. Giữ đúng đường dẫn này trong project LaTeX; chỉ copy file `.tex` sẽ không có ảnh.

## Biên dịch toàn bộ báo cáo online

Tải lên toàn bộ `Forest_Sokoban_Online_Compile.zip` và chọn `main.tex` ở thư mục gốc làm main document. Giữ nguyên `Forest_Sokoban_A01_Sections_7_to_End.tex`, `hcmut.png` và thư mục `figures/ui/compact/`; đây là các tệp được `main.tex` sử dụng.

`main.tex` trong gói này đã ghép nội dung báo cáo với Sections 7–9 và tài liệu tham khảo. Không dùng hướng dẫn “chèn vào template hiện tại” bên dưới cho gói compile toàn bộ.

## Chèn vào template hiện tại

Giữ nguyên phần đầu báo cáo và Sections 1–6. Thay từ Section 7 đến hết bằng:

```tex
\def\ForestSokobanIncludeMode{1}
\input{Forest_Sokoban_A01_Sections_7_to_End.tex}
\end{document}
```

Không giữ bibliography hoặc `\end{document}` cũ phía sau.

## Xem riêng phần 7 đến hết

Có thể biên dịch trực tiếp `Forest_Sokoban_A01_Sections_7_to_End.tex` bằng LaTeX. File tự tạo preamble khi không ở Include Mode.

Bản PDF xem trước được lưu trong `deliverables/Forest_Sokoban_UI_Report/`. Đây chỉ là phần tiếp nối, không phải báo cáo hợp nhất Sections 1–9.

## Trạng thái

- Bản gọn giữ 12 ảnh chính thay vì 57 ảnh. Các màn phụ và state variants được trình bày bằng screen inventory, bảng UI states và use cases; không xóa khỏi file Design gốc.
- Ảnh JPEG đã giảm dung lượng, tổng khoảng 2 MB. Không cần upload 63 PNG của bản đầy đủ lên Overleaf.
- Ảnh được dựng local từ file native `Forest UI v5 fixed.fig`; không phải screenshot xuất trực tiếp từ ứng dụng Figma. Provenance ở `figures/ui/compact/manifest.json`.
- Đã thêm link Design do người dùng cung cấp, nhưng không khẳng định đã kiểm tra quyền viewer hoặc interactions.
- UI tĩnh đã được review; nối interactions và chạy Present là công việc riêng.
- Vẫn ghi các chỉnh sửa nhỏ cần chốt: Empty history ở text 1.3×, chữ Guide và câu giải thích tài khoản.

Gói `deliverables/Forest_Sokoban_A01_UI_Ready.zip` đã được thay bằng bản gọn: `.tex`, chỉ 12 ảnh đang dùng và hướng dẫn. PDF được cung cấp riêng.