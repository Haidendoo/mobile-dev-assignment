# 12 ảnh chính cho bản báo cáo gọn

Giữ nguyên đường dẫn `figures/ui/compact/` khi đưa lên Overleaf hoặc chèn vào báo cáo khác.

Các ảnh gồm Home, Gameplay, chapter map, level selection, Completion, Story, Settings, Leaderboard, active Challenge lobby, Challenge results, OTP keyboard/error và Ending.

Ảnh được nén JPEG từ bản dựng local của `Forest UI v5 fixed.fig`, không chỉnh nội dung thiết kế. `manifest.json` ghi frame ID, file PNG nguồn và thiết lập nén. Tổng dung lượng ảnh khoảng 2 MB.

Các state phụ vẫn được mô tả trong bảng UI states và use cases của báo cáo. Bộ variants đầy đủ nằm trong file Design gốc.